const express = require('express');
const session = require('express-session');
const SQLiteStore = require('connect-sqlite3')(session);
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');

const app = express();
const db = new Database(path.join(__dirname, 'masomo_bora.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL, full_name TEXT NOT NULL,
 role TEXT NOT NULL CHECK(role IN ('admin','teacher','student','parent')),
 active INTEGER NOT NULL DEFAULT 1, created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS classes (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE NOT NULL, level TEXT DEFAULT 'Junior Secondary'
);
CREATE TABLE IF NOT EXISTS learners (
 id INTEGER PRIMARY KEY AUTOINCREMENT, admission_no TEXT UNIQUE NOT NULL,
 full_name TEXT NOT NULL, class_id INTEGER REFERENCES classes(id),
 gender TEXT, guardian TEXT, guardian_phone TEXT, status TEXT DEFAULT 'Active'
);
CREATE TABLE IF NOT EXISTS subjects (
 id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE NOT NULL, name TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS teacher_subjects (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER REFERENCES users(id),
 class_id INTEGER REFERENCES classes(id), subject_id INTEGER REFERENCES subjects(id),
 UNIQUE(user_id,class_id,subject_id)
);
CREATE TABLE IF NOT EXISTS exams (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, term TEXT NOT NULL,
 year INTEGER NOT NULL, max_score REAL NOT NULL DEFAULT 100, created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS marks (
 id INTEGER PRIMARY KEY AUTOINCREMENT, learner_id INTEGER REFERENCES learners(id),
 subject_id INTEGER REFERENCES subjects(id), exam_id INTEGER REFERENCES exams(id),
 score REAL NOT NULL CHECK(score >= 0), UNIQUE(learner_id,subject_id,exam_id)
);
CREATE TABLE IF NOT EXISTS attendance (
 id INTEGER PRIMARY KEY AUTOINCREMENT, learner_id INTEGER REFERENCES learners(id),
 date TEXT NOT NULL, status TEXT NOT NULL CHECK(status IN ('Present','Absent','Late','Excused')),
 note TEXT, UNIQUE(learner_id,date)
);
CREATE TABLE IF NOT EXISTS fee_invoices (
 id INTEGER PRIMARY KEY AUTOINCREMENT, learner_id INTEGER REFERENCES learners(id),
 description TEXT NOT NULL, amount REAL NOT NULL, due_date TEXT, status TEXT DEFAULT 'Unpaid',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS payments (
 id INTEGER PRIMARY KEY AUTOINCREMENT, invoice_id INTEGER REFERENCES fee_invoices(id),
 amount REAL NOT NULL, method TEXT NOT NULL, reference TEXT, paid_on TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS timetable (
 id INTEGER PRIMARY KEY AUTOINCREMENT, class_id INTEGER REFERENCES classes(id),
 day TEXT NOT NULL, period TEXT NOT NULL, subject_id INTEGER REFERENCES subjects(id),
 teacher_id INTEGER REFERENCES users(id), room TEXT
);
CREATE TABLE IF NOT EXISTS announcements (
 id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, message TEXT NOT NULL,
 audience TEXT DEFAULT 'All', created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
`);

const count = db.prepare('SELECT COUNT(*) n FROM users').get().n;
if (!count) {
 const hash = bcrypt.hashSync('ChangeMe123!', 12);
 db.prepare('INSERT INTO users(username,password_hash,full_name,role) VALUES(?,?,?,?)')
   .run('admin', hash, 'System Administrator', 'admin');
 ['Grade 7','Grade 8','Grade 9'].forEach(n => db.prepare('INSERT INTO classes(name) VALUES(?)').run(n));
 const subs = [['ENG','English'],['KIS','Kiswahili'],['MAT','Mathematics'],['SST','Social Studies'],['SCI','Integrated Science'],['AGR','Agriculture'],['CRE','Christian Religious Education'],['MUS','Music and Creative Arts'],['PHE','Physical and Health Education'],['PRE','Pre-Technical Studies']];
 const ins = db.prepare('INSERT INTO subjects(code,name) VALUES(?,?)');
 subs.forEach(s=>ins.run(...s));
}

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({limit:'1mb'}));
app.use(session({
 store: new SQLiteStore({ db: 'sessions.sqlite', dir: __dirname }),
 secret: process.env.SESSION_SECRET || 'change-this-secret-before-deployment',
 resave: false, saveUninitialized: false,
 cookie: { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', maxAge: 8*60*60*1000 }
}));
const loginLimiter = rateLimit({windowMs:15*60*1000, max:10, standardHeaders:true, legacyHeaders:false});
const auth = (req,res,next) => req.session.user ? next() : res.status(401).json({error:'Please sign in.'});
const admin = (req,res,next) => req.session.user?.role === 'admin' ? next() : res.status(403).json({error:'Administrator access required.'});
const safe = u => ({id:u.id,username:u.username,full_name:u.full_name,role:u.role});

app.post('/api/login', loginLimiter, (req,res)=>{
 const {username,password}=req.body||{};
 const user=db.prepare('SELECT * FROM users WHERE username=? AND active=1').get(username||'');
 if(!user || !bcrypt.compareSync(password||'',user.password_hash)) return res.status(401).json({error:'Incorrect username or password.'});
 req.session.regenerate(err=>{if(err)return res.status(500).json({error:'Could not start session.'}); req.session.user=safe(user); res.json({user:req.session.user});});
});
app.post('/api/logout',(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get('/api/me',(req,res)=>res.json({user:req.session.user||null}));
app.get('/api/bootstrap',auth,(req,res)=>{
 const q=(sql)=>db.prepare(sql).all();
 res.json({
  user:req.session.user, classes:q('SELECT * FROM classes ORDER BY name'),
  subjects:q('SELECT * FROM subjects ORDER BY name'),
  learners:q(`SELECT l.*,c.name class_name FROM learners l LEFT JOIN classes c ON c.id=l.class_id ORDER BY l.full_name`),
  exams:q('SELECT * FROM exams ORDER BY year DESC,id DESC'),
  announcements:q('SELECT * FROM announcements ORDER BY id DESC LIMIT 20'),
  stats:{
   learners:db.prepare("SELECT COUNT(*) n FROM learners WHERE status='Active'").get().n,
   staff:db.prepare("SELECT COUNT(*) n FROM users WHERE role='teacher' AND active=1").get().n,
   classes:db.prepare('SELECT COUNT(*) n FROM classes').get().n,
   exams:db.prepare('SELECT COUNT(*) n FROM exams').get().n
  }
 });
});
function crud(route, table, fields, required, adminOnly=true) {
 app.get('/api/'+route,auth,(req,res)=>res.json(db.prepare(`SELECT * FROM ${table} ORDER BY id DESC`).all()));
 app.post('/api/'+route,auth,...(adminOnly?[admin]:[]),(req,res)=>{
  const data=req.body||{};
  for(const f of required) if(data[f]===undefined || data[f]==='') return res.status(400).json({error:`${f} is required.`});
  const cols=fields.filter(f=>data[f]!==undefined);
  if(!cols.length)return res.status(400).json({error:'No fields supplied.'});
  try {
   const result=db.prepare(`INSERT INTO ${table} (${cols.join(',')}) VALUES (${cols.map(()=>'?').join(',')})`).run(...cols.map(f=>data[f]));
   res.json(db.prepare(`SELECT * FROM ${table} WHERE id=?`).get(result.lastInsertRowid));
  } catch(e){res.status(400).json({error:e.message.includes('UNIQUE')?'That record already exists.':e.message});}
 });
 app.put('/api/'+route+'/:id',auth,...(adminOnly?[admin]:[]),(req,res)=>{
  const cols=fields.filter(f=>req.body?.[f]!==undefined);
  if(!cols.length)return res.status(400).json({error:'No changes supplied.'});
  try {
   const info=db.prepare(`UPDATE ${table} SET ${cols.map(f=>f+'=?').join(',')} WHERE id=?`).run(...cols.map(f=>req.body[f]),req.params.id);
   if(!info.changes)return res.status(404).json({error:'Record not found.'});
   res.json(db.prepare(`SELECT * FROM ${table} WHERE id=?`).get(req.params.id));
  }catch(e){res.status(400).json({error:e.message});}
 });
 app.delete('/api/'+route+'/:id',auth,admin,(req,res)=>{
  try{const info=db.prepare(`DELETE FROM ${table} WHERE id=?`).run(req.params.id);res.json({deleted:!!info.changes});}
  catch(e){res.status(400).json({error:'This record is in use and cannot be deleted.'});}
 });
}
crud('classes','classes',['name','level'],['name']);
crud('subjects','subjects',['code','name'],['code','name']);
crud('learners','learners',['admission_no','full_name','class_id','gender','guardian','guardian_phone','status'],['admission_no','full_name']);
crud('exams','exams',['name','term','year','max_score'],['name','term','year']);
crud('announcements','announcements',['title','message','audience'],['title','message']);
app.get('/api/users',auth,admin,(req,res)=>res.json(db.prepare('SELECT id,username,full_name,role,active FROM users ORDER BY id DESC').all()));
app.post('/api/users',auth,admin,(req,res)=>{
 const {username,full_name,role,password}=req.body||{};
 if(!username||!full_name||!role||!password)return res.status(400).json({error:'Username, full name, role and temporary password are required.'});
 if(String(password).length<8)return res.status(400).json({error:'Temporary password must be at least 8 characters.'});
 try{const r=db.prepare('INSERT INTO users(username,password_hash,full_name,role) VALUES(?,?,?,?)').run(username,bcrypt.hashSync(password,12),full_name,role);res.json({id:r.lastInsertRowid,username,full_name,role,active:1});}
 catch(e){res.status(400).json({error:e.message.includes('UNIQUE')?'Username already exists.':e.message});}
});
app.delete('/api/users/:id',auth,admin,(req,res)=>{if(Number(req.params.id)===req.session.user.id)return res.status(400).json({error:'You cannot delete your own account.'});try{const r=db.prepare('DELETE FROM users WHERE id=?').run(req.params.id);res.json({deleted:!!r.changes});}catch(e){res.status(400).json({error:'User cannot be deleted.'});}});

app.post('/api/users/:id/password',auth,admin,(req,res)=>{
 const p=String(req.body.password||''); if(p.length<8)return res.status(400).json({error:'Use at least 8 characters.'});
 db.prepare('UPDATE users SET password_hash=? WHERE id=?').run(bcrypt.hashSync(p,12),req.params.id);res.json({ok:true});
});
app.get('/api/marks',auth,(req,res)=>{
 const rows=db.prepare(`SELECT m.*,l.full_name learner_name,l.admission_no,s.name subject_name,e.name exam_name,e.max_score,c.name class_name
 FROM marks m JOIN learners l ON l.id=m.learner_id JOIN subjects s ON s.id=m.subject_id JOIN exams e ON e.id=m.exam_id LEFT JOIN classes c ON c.id=l.class_id ORDER BY l.full_name`).all();
 res.json(rows);
});
app.post('/api/marks',auth,(req,res)=>{
 const {learner_id,subject_id,exam_id,score}=req.body||{};
 const exam=db.prepare('SELECT max_score FROM exams WHERE id=?').get(exam_id);
 if(!learner_id||!subject_id||!exam_id||score===undefined||!exam)return res.status(400).json({error:'Complete all mark fields.'});
 if(Number(score)<0||Number(score)>exam.max_score)return res.status(400).json({error:`Score must be between 0 and ${exam.max_score}.`});
 db.prepare(`INSERT INTO marks(learner_id,subject_id,exam_id,score) VALUES(?,?,?,?)
 ON CONFLICT(learner_id,subject_id,exam_id) DO UPDATE SET score=excluded.score`).run(learner_id,subject_id,exam_id,score);
 res.json({ok:true});
});
app.delete('/api/marks/:id',auth,admin,(req,res)=>res.json({deleted:!!db.prepare('DELETE FROM marks WHERE id=?').run(req.params.id).changes}));
app.get('/api/results/:examId',auth,(req,res)=>{
 const rows=db.prepare(`SELECT l.id learner_id,l.admission_no,l.full_name,c.name class_name,
 COUNT(m.id) subjects,ROUND(SUM(m.score),2) total,ROUND(AVG(m.score),2) average
 FROM learners l LEFT JOIN classes c ON c.id=l.class_id LEFT JOIN marks m ON m.learner_id=l.id AND m.exam_id=?
 WHERE l.status='Active' GROUP BY l.id ORDER BY average DESC,total DESC`).all(req.params.examId);
 res.json(rows.map((r,i)=>({...r,position:i+1})));
});
app.post('/api/attendance',auth,(req,res)=>{
 const {learner_id,date,status,note}=req.body||{};
 if(!learner_id||!date||!status)return res.status(400).json({error:'Learner, date and status are required.'});
 db.prepare(`INSERT INTO attendance(learner_id,date,status,note) VALUES(?,?,?,?)
 ON CONFLICT(learner_id,date) DO UPDATE SET status=excluded.status,note=excluded.note`).run(learner_id,date,status,note||'');
 res.json({ok:true});
});
app.get('/api/attendance',auth,(req,res)=>res.json(db.prepare(`SELECT a.*,l.full_name learner_name,l.admission_no FROM attendance a JOIN learners l ON l.id=a.learner_id ORDER BY date DESC,l.full_name`).all()));
app.post('/api/invoices',auth,admin,(req,res)=>{
 const {learner_id,description,amount,due_date}=req.body||{};
 if(!learner_id||!description||!(Number(amount)>0))return res.status(400).json({error:'Learner, description and a positive amount are required.'});
 const r=db.prepare('INSERT INTO fee_invoices(learner_id,description,amount,due_date) VALUES(?,?,?,?)').run(learner_id,description,amount,due_date||null);
 res.json({id:r.lastInsertRowid});
});
app.get('/api/invoices',auth,(req,res)=>res.json(db.prepare(`SELECT i.*,l.full_name learner_name,l.admission_no,COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.invoice_id=i.id),0) paid FROM fee_invoices i JOIN learners l ON l.id=i.learner_id ORDER BY i.id DESC`).all()));
app.post('/api/payments',auth,admin,(req,res)=>{
 const {invoice_id,amount,method,reference}=req.body||{};
 const inv=db.prepare('SELECT * FROM fee_invoices WHERE id=?').get(invoice_id);
 if(!inv||!(Number(amount)>0)||!method)return res.status(400).json({error:'Valid invoice, amount and payment method are required.'});
 const paid=db.prepare('SELECT COALESCE(SUM(amount),0) n FROM payments WHERE invoice_id=?').get(invoice_id).n;
 if(Number(amount)>inv.amount-paid)return res.status(400).json({error:'Payment exceeds outstanding balance.'});
 db.prepare('INSERT INTO payments(invoice_id,amount,method,reference) VALUES(?,?,?,?)').run(invoice_id,amount,method,reference||'');
 const newPaid=paid+Number(amount); db.prepare('UPDATE fee_invoices SET status=? WHERE id=?').run(newPaid>=inv.amount?'Paid':'Part-paid',invoice_id);
 res.json({ok:true});
});
app.get('/api/timetable',auth,(req,res)=>res.json(db.prepare(`SELECT t.*,c.name class_name,s.name subject_name,u.full_name teacher_name FROM timetable t LEFT JOIN classes c ON c.id=t.class_id LEFT JOIN subjects s ON s.id=t.subject_id LEFT JOIN users u ON u.id=t.teacher_id ORDER BY CASE day WHEN 'Monday' THEN 1 WHEN 'Tuesday' THEN 2 WHEN 'Wednesday' THEN 3 WHEN 'Thursday' THEN 4 WHEN 'Friday' THEN 5 ELSE 6 END,period`).all()));
app.post('/api/timetable',auth,admin,(req,res)=>{
 const {class_id,day,period,subject_id,teacher_id,room}=req.body||{};
 if(!class_id||!day||!period||!subject_id)return res.status(400).json({error:'Class, day, period and subject are required.'});
 const r=db.prepare('INSERT INTO timetable(class_id,day,period,subject_id,teacher_id,room) VALUES(?,?,?,?,?,?)').run(class_id,day,period,subject_id,teacher_id||null,room||'');
 res.json({id:r.lastInsertRowid});
});
app.delete('/api/timetable/:id',auth,admin,(req,res)=>res.json({deleted:!!db.prepare('DELETE FROM timetable WHERE id=?').run(req.params.id).changes}));
app.get('/api/teachers',auth,(req,res)=>res.json(db.prepare("SELECT id,full_name,username FROM users WHERE role='teacher' AND active=1 ORDER BY full_name").all()));
app.get('/api/reports/summary',auth,(req,res)=>res.json({
 attendance:db.prepare("SELECT status,COUNT(*) count FROM attendance GROUP BY status").all(),
 fees:db.prepare("SELECT status,COUNT(*) count,COALESCE(SUM(amount),0) amount FROM fee_invoices GROUP BY status").all(),
 marks:db.prepare("SELECT COUNT(*) count,ROUND(AVG(score),1) average FROM marks").get()
}));
app.use(express.static(path.join(__dirname,'public')));
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
const port=process.env.PORT||3000;
app.listen(port,()=>console.log(`Masomo Bora School System running at http://localhost:${port}`));
