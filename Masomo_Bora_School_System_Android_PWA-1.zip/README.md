# Masomo Bora School System

Masomo Bora is a responsive CBC / Junior Secondary school management web application with an installable Android-style home-screen experience (Progressive Web App / PWA).

## Modules included
- Administrator login and role-based user records
- Learner register, classes and CBC subjects
- Examination setup and marks entry/update
- Result computation and merit ranking
- Attendance tracking
- Timetable lesson records
- Fee invoices and manual payment recording
- Announcements and summary reports

## Android phone access
This package is the application source code, not a ready-to-install APK. It is configured as an installable PWA:
1. The app must first be deployed to an HTTPS web host with Node.js support and persistent storage.
2. Open its HTTPS address in Google Chrome on Android.
3. Open Chrome's three-dot menu and choose **Install app** or **Add to Home screen**.
4. Masomo Bora will then have an app icon and open in an app-like full-screen window.

The school database and login require the hosted server and an internet connection. The service worker caches the visual app shell only; it does not make the database or records work offline.

## Server setup
Requires Node.js 18+:
1. `npm install`
2. Copy `.env.example` to `.env`.
3. Set a long random `SESSION_SECRET`.
4. `npm start`
5. Open `http://localhost:3000` for local development.

First login: `admin` / `ChangeMe123!`. Change this password before real use.

## Production requirements
This is a functional starter/MVP, not a production-certified school deployment. Before using real learner data:
- Deploy behind HTTPS and use a strong unique session secret.
- Add secure password-change flow and enforce first-login password changes.
- Configure persistent backups and a production session store.
- Add granular teacher/class/subject and parent/student account permissions and linking.
- Review Kenya Data Protection Act obligations, consent, retention, access logging and breach response.
- Integrate M-Pesa using an approved Daraja application and verified server-side callbacks. Current payments are manual records only.
- Add PDF/Excel report generation and confirm school-specific CBC assessment/report formats.
- Add grading rubrics, learning-area competencies and relevant CBC reporting workflows.

## Database
SQLite database is created automatically in the application folder as `masomo_bora.db`. Back it up securely and regularly.
